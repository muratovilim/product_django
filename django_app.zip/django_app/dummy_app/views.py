from django.shortcuts import render

# Create your views here.
def james(request):
    return HttpResponse
    ('Hello James')
