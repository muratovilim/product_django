from django.contrib import admin

# Register your models here.
class ProductAdmin(admin.ModelAdmin):
    list_display=['title', 'description', 'updated','timestamp']
    list_display_links = ['title']
    list_filter = ['title', 'updated', 'timestamp']
    search_fields = ['title', 'description']
from .models import Product
admin.site.register(Product, ProductAdmin)