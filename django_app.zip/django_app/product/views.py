from django.shortcuts import render
from django.http import HttpResponse
from .models import Product


# Create your views here.
def index(request):
    return render(request, "product/index.html")


def greet(request, name):
    name = {"name": name.capitalize()}
    return render(request, "product/greet.html", name)

def product_list(request):
    queryset = Product.objects.all()
    context = {
        "object_list": queryset,
        "title": "List"
    }
    return render(request, "product/index.html", context)
